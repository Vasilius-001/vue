<template>
	<v-row>
		<v-col>
			<webcam-panel></webcam-panel>
		</v-col>
	</v-row>
</template>
