'use strict'

import Status from './Status.vue'
import Webcam from './Webcam.vue'

export default {
	Status,
	Webcam
}
