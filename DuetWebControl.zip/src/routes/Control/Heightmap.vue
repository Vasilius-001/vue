<template>
	<v-row>
		<v-col>
			<heightmap-panel></heightmap-panel>
		</v-col>
	</v-row>
</template>
