<template>
	<v-row>
		<v-col>
			<system-file-list></system-file-list>
		</v-col>
	</v-row>
</template>
