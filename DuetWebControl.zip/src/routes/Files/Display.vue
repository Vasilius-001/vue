<template>
	<v-row>
		<v-col>
			<display-file-list></display-file-list>
		</v-col>
	</v-row>
</template>
