<template>
	<v-row>
		<v-col>
			<macro-file-list></macro-file-list>
		</v-col>
	</v-row>
</template>
