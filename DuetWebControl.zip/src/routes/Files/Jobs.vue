<template>
	<v-row>
		<v-col>
			<job-file-list></job-file-list>
		</v-col>
	</v-row>
</template>
