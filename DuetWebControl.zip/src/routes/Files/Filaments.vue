<template>
	<v-row>
		<v-col>
			<filament-file-list></filament-file-list>
		</v-col>
	</v-row>
</template>
