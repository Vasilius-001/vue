'use strict'

import General from './General.vue'
import Machine from './Machine.vue'

export default {
	General,
	Machine
}
